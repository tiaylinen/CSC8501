Visual studio 2019 project can be found in the folder called mazegeneration.
Tick sheet is available in the root directory, same as this file. 
Executable file is in folder mazegeneration > Debug 
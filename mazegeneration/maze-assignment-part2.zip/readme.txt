Visual studio 2019 project can be found in the folder called collaborativepathfinding.
Executable file is in folder collaborativepathfinding > Debug.

Tick sheet is available in the root directory, same as this file. One note about that:
In my solution the maze is never completely unsolvable. Some players can't reach the finish point if other players get on their way.
At least one player will still always get there. In case a player gets blocked by another player, the program will notify about it.